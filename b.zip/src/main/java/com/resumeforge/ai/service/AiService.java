package com.resumeforge.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.resumeforge.ai.dto.AiRequest;
import com.resumeforge.ai.dto.AiResponse;
import com.resumeforge.ai.entity.AiUsageLog;
import com.resumeforge.ai.entity.User;
import com.resumeforge.ai.exception.AiException;
import com.resumeforge.ai.exception.RateLimitException;
import com.resumeforge.ai.repository.AiUsageLogRepository;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * AI-01 FIX — Production-hardened OpenRouter client.
 *
 * Bugs fixed vs the previous version:
 *
 * 1. {@code @Retryable} on a private method is silently ignored by Spring AOP.
 *    AOP proxies only intercept calls coming through the proxy (external calls).
 *    {@code callOpenRouter()} is a private method invoked internally — the proxy
 *    is bypassed, so {@code @Retryable} never fires.
 *    FIX: Replaced with a programmatic {@link RetryTemplate} constructed in
 *    {@code @PostConstruct init()} and invoked directly inside the method.
 *
 * 2. Timeout values were hardcoded as {@code static final int} constants.
 *    FIX: Wired from {@code @Value} so Render environment variables
 *    {@code OPENROUTER_CONNECT_TIMEOUT_MS} / {@code OPENROUTER_READ_TIMEOUT_MS}
 *    can tune them without a code deploy.
 *
 * 3. Every HTTP error from OpenRouter ({@code HttpClientErrorException}) was
 *    caught by the generic {@code catch(Exception e)} block and rethrown as a
 *    bare {@code RuntimeException("AI service error: 401 Unauthorized")}.
 *    FIX: Each HTTP status class maps to a typed {@link AiException} with a
 *    specific {@link AiException.ErrorCode} — 401→OPENROUTER_AUTH_ERROR,
 *    403→OPENROUTER_FORBIDDEN, 429→OPENROUTER_RATE_LIMIT, 5xx→OPENROUTER_UNAVAILABLE.
 *
 * 4. API key was exposed in log output.
 *    FIX: {@code maskKey()} shows only the last 4 characters in logs.
 *
 * 5. Null / blank OpenRouter response body caused NPE inside JSON parsing.
 *    FIX: Explicit null/blank checks before parsing with typed error.
 */
@Service
public class AiService {

    private static final Logger log = LoggerFactory.getLogger(AiService.class);

    private static final int FREE_DAILY_LIMIT    = 5;
    private static final int PREMIUM_DAILY_LIMIT = 50;

    @Autowired
    private AiUsageLogRepository aiUsageLogRepository;

    @Value("${app.openrouter.api-key}")
    private String openRouterApiKey;

    @Value("${app.openrouter.base-url}")
    private String openRouterBaseUrl;

    @Value("${app.openrouter.model}")
    private String model;

    @Value("${app.openrouter.site-url}")
    private String siteUrl;

    @Value("${app.openrouter.site-name}")
    private String siteName;

    /**
     * AI-01 FIX: Wire timeouts from application.properties so they can be
     * overridden via Render environment variables without a code redeploy.
     *   OPENROUTER_CONNECT_TIMEOUT_MS (default 10 000 ms)
     *   OPENROUTER_READ_TIMEOUT_MS    (default 60 000 ms)
     */
    @Value("${app.openrouter.connect-timeout-ms:10000}")
    private int connectTimeoutMs;

    @Value("${app.openrouter.read-timeout-ms:60000}")
    private int readTimeoutMs;

    private RestTemplate restTemplate;
    private RetryTemplate retryTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    // ── Startup ───────────────────────────────────────────────────────────────

    /**
     * AI-01 FIX: Validates OPENROUTER_API_KEY at startup and builds the
     * RestTemplate (with timeouts) and RetryTemplate (for 5xx retries).
     */
    @PostConstruct
    public void init() {
        // 1. Validate API key — fail fast if missing
        if (openRouterApiKey == null || openRouterApiKey.isBlank()) {
            throw new IllegalStateException(
                    "[AiService] OPENROUTER_API_KEY is not set or blank. " +
                            "All AI endpoints will return errors. " +
                            "Fix: Render dashboard → your service → Environment → " +
                            "Add environment variable: OPENROUTER_API_KEY = sk-or-v1-..."
            );
        }
        if (openRouterApiKey.length() < 20) {
            log.warn("[AiService] OPENROUTER_API_KEY is unusually short ({} chars, tail='…{}').",
                    openRouterApiKey.length(), maskKey(openRouterApiKey));
        }

        // 2. Build RestTemplate with configurable timeouts
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(connectTimeoutMs);
        factory.setReadTimeout(readTimeoutMs);
        restTemplate = new RestTemplate(factory);

        // 3. Build RetryTemplate for transient 5xx / network errors.
        //
        // AI-01 FIX: @Retryable on a private method is silently ignored by Spring AOP.
        // Spring AOP proxies only intercept calls that come through the proxy
        // (external calls to a Spring bean). callOpenRouter() is private and
        // called from within the same bean — the call never touches the proxy,
        // so @Retryable has zero effect.
        //
        // Solution: RetryTemplate invoked programmatically inside the method body.
        // Only OPENROUTER_UNAVAILABLE (5xx / network) is retried — auth errors
        // and client errors (401/403/429) are NOT retried (they won't self-heal).
        Map<Class<? extends Throwable>, Boolean> retryableExceptions = new HashMap<>();
        // Only retry AiException — the specific sub-type is checked in the
        // RetryPolicy below via a custom check in the retry callback itself.
        // We use SimpleRetryPolicy with maxAttempts=3 total (1 original + 2 retries).
        RetryPolicy retryPolicy = new SimpleRetryPolicy(3, retryableExceptions, true) {
            @Override
            public boolean canRetry(org.springframework.retry.RetryContext context) {
                Throwable lastThrowable = context.getLastThrowable();
                if (lastThrowable == null) return true; // first attempt
                // Only retry UNAVAILABLE errors — not auth or client errors
                if (lastThrowable instanceof AiException ae) {
                    return ae.getErrorCode() == AiException.ErrorCode.OPENROUTER_UNAVAILABLE
                            && context.getRetryCount() < 2; // max 2 retries
                }
                return false; // do not retry any other exception type
            }
        };

        ExponentialBackOffPolicy backOff = new ExponentialBackOffPolicy();
        backOff.setInitialInterval(1_500);   // 1.5 s before first retry
        backOff.setMultiplier(2.0);           // 1.5 s, 3 s
        backOff.setMaxInterval(10_000);       // cap at 10 s

        retryTemplate = new RetryTemplate();
        retryTemplate.setRetryPolicy(retryPolicy);
        retryTemplate.setBackOffPolicy(backOff);
        retryTemplate.setThrowLastExceptionOnExhausted(true);

        log.info("[AiService] Initialised. model='{}', connectTimeout={}ms, " +
                        "readTimeout={}ms, keyTail='…{}'.",
                model, connectTimeoutMs, readTimeoutMs, maskKey(openRouterApiKey));
    }

    // ── Public async entry points ─────────────────────────────────────────────

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> rewriteContent(User user, AiRequest request) {
        return callOpenRouter(user, "rewrite", buildRewritePrompt(request.getContent()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> improveBullets(User user, AiRequest request) {
        return callOpenRouter(user, "bullets", buildBulletPrompt(request.getContent()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> generateSummary(User user, AiRequest request) {
        return callOpenRouter(user, "summary",
                buildSummaryPrompt(request.getContent(), request.getContext()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> extractSkills(User user, AiRequest request) {
        return callOpenRouter(user, "skills", buildSkillsPrompt(request.getContent()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> tailorToJob(User user, AiRequest request) {
        return callOpenRouter(user, "tailor",
                buildTailorPrompt(request.getContent(), request.getJobDescription()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> atsScore(User user, AiRequest request) {
        return callOpenRouter(user, "ats_score",
                buildAtsScorePrompt(request.getContent(), request.getJobDescription()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> generateCoverLetter(User user, AiRequest request) {
        return callOpenRouter(user, "cover_letter",
                buildCoverLetterPrompt(request.getContent(), request.getJobDescription()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> optimizeLinkedIn(User user, AiRequest request) {
        return callOpenRouter(user, "linkedin", buildLinkedInPrompt(request.getContent()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> checkGrammar(User user, AiRequest request) {
        return callOpenRouter(user, "grammar_check",
                buildGrammarCheckPrompt(request.getContent()));
    }

    @Async("aiTaskExecutor")
    public CompletableFuture<AiResponse> generateInterviewPrep(User user, AiRequest request) {
        return callOpenRouter(user, "interview_prep",
                buildInterviewPrepPrompt(request.getContent(), request.getJobDescription()));
    }

    // ── Core call (private, uses RetryTemplate programmatically) ─────────────

    private CompletableFuture<AiResponse> callOpenRouter(
            User user, String feature, String prompt) {

        // Per-user daily rate limit
        int limit = user.isPremium() ? PREMIUM_DAILY_LIMIT : FREE_DAILY_LIMIT;
        LocalDateTime windowStart = LocalDateTime.now().minusHours(24);
        long usageCount = aiUsageLogRepository
                .countByUserIdAndCreatedAtAfter(user.getId(), windowStart);

        if (usageCount >= limit) {
            String tier = user.isPremium() ? "Premium" : "Free";
            throw new RateLimitException(
                    tier + " plan limit reached (" + limit + " AI requests per day). " +
                            (user.isPremium() ? "Please try again tomorrow."
                                    : "Upgrade to Premium for higher limits.")
            );
        }

        // RetryTemplate wraps the HTTP call — retries only OPENROUTER_UNAVAILABLE
        AiResponse aiResponse = retryTemplate.execute(retryCtx -> {
            if (retryCtx.getRetryCount() > 0) {
                log.warn("[AiService] Retry attempt {} for feature='{}' after: {}",
                        retryCtx.getRetryCount(), feature,
                        retryCtx.getLastThrowable().getMessage());
            }
            return doHttpCall(user, feature, prompt);
        });

        return CompletableFuture.completedFuture(aiResponse);
    }

    /**
     * Performs the actual HTTP request to OpenRouter and parses the response.
     * All exceptions are mapped to typed {@link AiException} instances so
     * callers (RetryTemplate and AiController.handle()) can treat them correctly.
     */
    private AiResponse doHttpCall(User user, String feature, String prompt) {

        // Build headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(openRouterApiKey);
        headers.set("HTTP-Referer", siteUrl);
        headers.set("X-Title", siteName);

        // Build body
        Map<String, Object> body = new HashMap<>();
        body.put("model", model);
        body.put("messages", List.of(Map.of("role", "user", "content", prompt)));

        HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(body, headers);

        log.debug("[AiService] → OpenRouter feature='{}' userId={} model='{}'",
                feature, user.getId(), model);

        // Execute HTTP call — map each error class to typed AiException
        ResponseEntity<String> response;
        try {
            response = restTemplate.exchange(
                    openRouterBaseUrl, HttpMethod.POST, httpEntity, String.class);

        } catch (HttpClientErrorException.Unauthorized e) {
            // OpenRouter 401 — wrong/revoked API key
            log.error("[AiService] OpenRouter 401 Unauthorized. " +
                            "keyTail='…{}'. Check OPENROUTER_API_KEY on Render.",
                    maskKey(openRouterApiKey));
            throw new AiException(AiException.ErrorCode.OPENROUTER_AUTH_ERROR,
                    "OpenRouter authentication failed. The API key is invalid or revoked. " +
                            "Check OPENROUTER_API_KEY in Render Environment Variables.", e);

        } catch (HttpClientErrorException.Forbidden e) {
            // OpenRouter 403 — model access denied / account suspended
            log.error("[AiService] OpenRouter 403 Forbidden for feature='{}'. " +
                    "Model '{}' may require a different plan.", feature, model);
            throw new AiException(AiException.ErrorCode.OPENROUTER_FORBIDDEN,
                    "Access to the AI model was denied. The model '" + model +
                            "' may require a paid OpenRouter subscription.", e);

        } catch (HttpClientErrorException.TooManyRequests e) {
            // OpenRouter 429 — their upstream rate limit
            log.warn("[AiService] OpenRouter upstream 429 for feature='{}'.", feature);
            throw new AiException(AiException.ErrorCode.OPENROUTER_RATE_LIMIT,
                    "The AI provider is temporarily rate-limited. Please wait and try again.", e);

        } catch (HttpClientErrorException e) {
            // Other 4xx (e.g. 400 malformed prompt)
            log.error("[AiService] OpenRouter {} for feature='{}': {}",
                    e.getStatusCode(), feature, e.getResponseBodyAsString());
            throw new AiException(AiException.ErrorCode.AI_SERVICE_ERROR,
                    "AI request rejected (HTTP " + e.getStatusCode().value() +
                            "). Check your request content.", e);

        } catch (HttpServerErrorException e) {
            // OpenRouter 5xx — RetryTemplate will retry this
            log.warn("[AiService] OpenRouter {} for feature='{}'. Retrying...",
                    e.getStatusCode(), feature);
            throw new AiException(AiException.ErrorCode.OPENROUTER_UNAVAILABLE,
                    "The AI provider is temporarily unavailable (HTTP " +
                            e.getStatusCode().value() + "). Please try again shortly.", e);

        } catch (ResourceAccessException e) {
            // Network timeout or connection refused — RetryTemplate will retry this
            log.warn("[AiService] Network error reaching OpenRouter for feature='{}': {}",
                    feature, e.getMessage());
            throw new AiException(AiException.ErrorCode.OPENROUTER_UNAVAILABLE,
                    "Could not reach the AI service (network error). Please try again.", e);

        } catch (Exception e) {
            log.error("[AiService] Unexpected error for feature='{}': {}", feature, e.getMessage(), e);
            throw new AiException(AiException.ErrorCode.AI_SERVICE_ERROR,
                    "An unexpected error occurred while calling the AI service.", e);
        }

        // Parse response body
        try {
            String responseBody = response.getBody();

            if (responseBody == null || responseBody.isBlank()) {
                log.error("[AiService] OpenRouter returned empty body for feature='{}'.", feature);
                throw new AiException(AiException.ErrorCode.OPENROUTER_EMPTY_RESPONSE,
                        "The AI service returned an empty response. Please try again.");
            }

            JsonNode json   = objectMapper.readTree(responseBody);
            String   result = json.at("/choices/0/message/content").asText(null);

            if (result == null || result.isBlank()) {
                log.error("[AiService] Empty content in OpenRouter response for feature='{}'. " +
                        "Body: {}", feature, responseBody);
                throw new AiException(AiException.ErrorCode.OPENROUTER_EMPTY_RESPONSE,
                        "The AI service returned no content. Please try again.");
            }

            int inputTokens  = json.at("/usage/prompt_tokens").asInt(0);
            int outputTokens = json.at("/usage/completion_tokens").asInt(0);

            log.debug("[AiService] ← OpenRouter OK feature='{}' userId={} in={} out={}",
                    feature, user.getId(), inputTokens, outputTokens);

            // Persist usage log
            aiUsageLogRepository.save(AiUsageLog.builder()
                    .userId(user.getId())
                    .feature(feature)
                    .inputTokens(inputTokens)
                    .outputTokens(outputTokens)
                    .build());

            return AiResponse.builder()
                    .result(result)
                    .inputTokens(inputTokens)
                    .outputTokens(outputTokens)
                    .build();

        } catch (AiException e) {
            throw e; // re-throw typed exceptions unchanged
        } catch (Exception e) {
            log.error("[AiService] Failed to parse OpenRouter response for feature='{}': {}",
                    feature, e.getMessage(), e);
            throw new AiException(AiException.ErrorCode.AI_SERVICE_ERROR,
                    "Failed to parse the AI response. Please try again.", e);
        }
    }

    // ── Key masking ───────────────────────────────────────────────────────────

    /** Shows only the last 4 characters — never expose the full key in logs. */
    private String maskKey(String key) {
        if (key == null || key.length() < 4) return "****";
        return key.substring(key.length() - 4);
    }

    // ── Prompt builders ───────────────────────────────────────────────────────

    private String buildRewritePrompt(String content) {
        return "Rewrite the following resume content to be more professional, impactful, and " +
                "ATS-friendly. Use strong action verbs and quantify achievements where possible:\n\n"
                + content;
    }

    private String buildBulletPrompt(String content) {
        return "Improve these resume bullet points to be more impactful and ATS-friendly. " +
                "Start with strong action verbs, quantify achievements, and highlight results:\n\n"
                + content;
    }

    private String buildSummaryPrompt(String content, String context) {
        String base = "Create a professional resume summary that highlights key skills and " +
                "achievements. Make it compelling and ATS-friendly.";
        if (context != null && !context.isBlank()) {
            base += " Context: " + context;
        }
        return base + "\n\nResume details:\n" + content;
    }

    private String buildSkillsPrompt(String content) {
        return "Extract and categorize technical and soft skills from the following resume " +
                "content. Return as a structured list:\n\n" + content;
    }

    private String buildTailorPrompt(String content, String jobDescription) {
        return "Tailor this resume content to match the following job description. " +
                "Emphasize relevant skills and experience while maintaining honesty:\n\n" +
                "Job Description:\n" + (jobDescription != null ? jobDescription : "Not provided") +
                "\n\nResume Content:\n" + content;
    }

    private String buildAtsScorePrompt(String content, String jobDescription) {
        return "Analyze this resume for ATS compatibility and job match. " +
                "Provide a score (0-100) and specific recommendations:\n\n" +
                "Job Description:\n" + (jobDescription != null ? jobDescription : "General analysis") +
                "\n\nResume:\n" + content;
    }

    private String buildCoverLetterPrompt(String content, String jobDescription) {
        return "Write a professional cover letter based on this resume and job description. " +
                "Make it personalized, enthusiastic, and highlight relevant qualifications:\n\n" +
                "Job Description:\n" + (jobDescription != null ? jobDescription : "Not provided") +
                "\n\nResume:\n" + content;
    }

    private String buildLinkedInPrompt(String content) {
        return "Optimize this resume content for LinkedIn. Create compelling sections for:\n" +
                "1. Headline\n2. About/Summary\n3. Experience highlights\n\nResume:\n" + content;
    }

    private String buildGrammarCheckPrompt(String content) {
        return "Check this resume content for grammar, spelling, and clarity issues. " +
                "Provide corrected version and explanation of changes:\n\n" + content;
    }

    private String buildInterviewPrepPrompt(String content, String jobDescription) {
        return "Based on this resume and job description, generate 10 likely interview questions " +
                "with suggested answers:\n\n" +
                "Job Description:\n" + (jobDescription != null ? jobDescription : "General questions") +
                "\n\nResume:\n" + content;
    }
}