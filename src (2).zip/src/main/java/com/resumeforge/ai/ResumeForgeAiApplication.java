package com.resumeforge.ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class ResumeForgeAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResumeForgeAiApplication.class, args);
    }
}
